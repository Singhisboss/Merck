import os
import pandas as pd
from flask import Flask, request, render_template, send_from_directory, flash, redirect, url_for, session
import datetime

# Get the absolute path of the directory where app.py is located
basedir = os.path.abspath(os.path.dirname(__file__))

# --- Configuration ---
# Use absolute paths for folders to avoid ambiguity
DOWNLOAD_FOLDER = os.path.join(basedir, 'downloads')

app = Flask(__name__, template_folder='templates') # Assuming your folder is named 'templates'
app.config['DOWNLOAD_FOLDER'] = DOWNLOAD_FOLDER
app.config['SECRET_KEY'] = 'supersecretkey' # Needed for flashing messages and sessions

# Ensure the upload and download directories exist
os.makedirs(app.config['DOWNLOAD_FOLDER'], exist_ok=True)


def process_excel_file(params):
    """
    Reads a main Excel file, filters by company, then filters by a list of designations
    from a second Excel file, and saves the result.
    Returns a tuple: (status, data).
    - params: A dictionary containing all file paths and filter criteria.
    On failure, status is "error" and data is the error message.
    On success, status is "success" and data is the count of filtered rows.
    """
    try:
        # --- Step 1: Read and filter the main report by Company ---
        try:
            main_excel_file = pd.ExcelFile(params['main_file_path'])
        except FileNotFoundError:
            return ("error", f"Error: Main report file not found at {params['main_file_path']}.")

        if params['main_sheet'] not in main_excel_file.sheet_names:
            return ("error", f"Error: Sheet '{params['main_sheet']}' not found in main report. Available sheets: {main_excel_file.sheet_names}")

        df_main = pd.read_excel(main_excel_file, sheet_name=params['main_sheet'])

        if params['main_company_col'] not in df_main.columns:
            return ("error", f"Error: Company column '{params['main_company_col']}' not found in main report. Available columns: {list(df_main.columns)}")

        df_main[params['main_company_col']] = df_main[params['main_company_col']].astype(str)
        df_company_filtered = df_main[df_main[params['main_company_col']].str.strip().str.lower() == params['company_name'].strip().lower()]

        if df_company_filtered.empty:
            return ("error", f"Notice: No data found for company '{params['company_name']}' in the main report.")

        # --- Step 2: Filter by the Allocation Report ---
        try:
            # Use the 'pyxlsb' engine for .xlsb files
            df_allocation = pd.read_excel(params['allocation_file_path'], sheet_name=params['allocation_sheet'], engine='pyxlsb')
        except FileNotFoundError:
            return ("error", f"Error: Allocation report file not found at {params['allocation_file_path']}.")
        except Exception as e:
            # Catches errors if sheet is not found in the .xlsb file
            return ("error", f"Error reading allocation report: {e}")

        if params['allocation_project_col'] not in df_allocation.columns:
            return ("error", f"Error: Project column '{params['allocation_project_col']}' not found in allocation report. Available columns: {list(df_allocation.columns)}")

        df_allocation[params['allocation_project_col']] = df_allocation[params['allocation_project_col']].astype(str)
        df_project_filtered = df_allocation[df_allocation[params['allocation_project_col']].str.strip().str.lower() == params['project_description'].strip().lower()]

        if df_project_filtered.empty:
            return ("error", f"Notice: No data found for project '{params['project_description']}' in the allocation report.")

        # --- Step 3: Find common associates between company and project filters ---
        if params['associate_id_col'] not in df_company_filtered.columns or params['associate_id_col'] not in df_project_filtered.columns:
            return ("error", f"Error: The common ID column '{params['associate_id_col']}' was not found in both the main report and the allocation report.")

        project_associate_ids = set(df_project_filtered[params['associate_id_col']].dropna().astype(str))
        df_company_filtered[params['associate_id_col']] = df_company_filtered[params['associate_id_col']].astype(str)
        df_company_and_project_filtered = df_company_filtered[df_company_filtered[params['associate_id_col']].isin(project_associate_ids)]

        if df_company_and_project_filtered.empty:
            return ("error", f"Notice: No common associates found between company '{params['company_name']}' and project '{params['project_description']}'.")

        # --- Step 4: Filter by Designation ---
        df_designations = pd.read_excel(params['designation_file_path'], sheet_name=params['designation_sheet'])
        designation_col_name = df_designations.columns[0]
        valid_designations = set(df_designations[designation_col_name].str.strip().str.lower())

        df_company_and_project_filtered[params['main_designation_col']] = df_company_and_project_filtered[params['main_designation_col']].astype(str)
        final_df = df_company_and_project_filtered[df_company_and_project_filtered[params['main_designation_col']].str.strip().str.lower().isin(valid_designations)]

        # Save the filtered data
        final_df.to_excel(params['output_path'], index=False, sheet_name=f"{params['company_name'][:20]} Filtered")
        return ("success", len(final_df))

    except Exception as e:
        return ("error", f"An unexpected error occurred: {e}")

@app.route('/')
def home():
    """Renders the new home page and clears the session for a fresh start."""
    session.clear()
    return render_template('index.html')


@app.route('/start', methods=['GET', 'POST'])
def start_processing():
    """Step 1: Get the file paths from the user."""
    # session.clear() # Removed to allow "Back" button to work correctly
    if request.method == 'POST':
        main_filepath = request.form.get('main_filepath')
        designation_filepath = request.form.get('designation_filepath')
        allocation_filepath = request.form.get('allocation_filepath')

        if not all([main_filepath, designation_filepath, allocation_filepath]):
            flash('Please provide paths for all three report files.', 'error')
            return redirect(url_for('start_processing'))

        if not all(os.path.exists(p) for p in [main_filepath, designation_filepath, allocation_filepath]):
            flash('One or more files were not found at the specified paths.', 'error')
            return redirect(url_for('start_processing'))

        session['main_filepath'] = main_filepath
        session['designation_filepath'] = designation_filepath
        session['allocation_filepath'] = allocation_filepath
        
        # --- New: Read the main file to populate the company dropdown ---
        try:
            # Using default sheet and column names to find companies.
            # A more advanced version could ask for these in Step 1.
            main_sheet = 'Associate Summary'
            main_company_col = 'Parent AccountName'
            
            df = pd.read_excel(main_filepath, sheet_name=main_sheet)
            
            if main_company_col not in df.columns:
                flash(f"Default company column '{main_company_col}' not found in sheet '{main_sheet}'. Please check the file.", 'error')
                return redirect(url_for('start_processing'))
                
            # Get unique, non-empty company names and sort them
            company_list = sorted([str(name) for name in df[main_company_col].dropna().unique() if str(name).strip()])
            
            if not company_list:
                flash(f"No company names found in column '{main_company_col}' of sheet '{main_sheet}'.", 'error')
                return redirect(url_for('start_processing'))

            session['company_list'] = company_list
        except Exception as e:
            flash(f"Error reading the main Excel file to get company names: {e}", 'error')
            return redirect(url_for('start_processing'))

        # --- New: Read the allocation file to populate the project dropdown ---
        try:
            # Using default sheet and column names to find projects.
            allocation_sheet = 'Base sheet'
            allocation_project_col = 'Project Description'
            # Tentative column for additional detail, assuming it exists.
            project_id_col = 'Project Code'
            
            df_alloc = pd.read_excel(allocation_filepath, sheet_name=allocation_sheet, engine='pyxlsb')
            
            if allocation_project_col not in df_alloc.columns:
                flash(f"Default project column '{allocation_project_col}' not found in sheet '{allocation_sheet}'. Please check the file.", 'error')
                return redirect(url_for('start_processing'))
                
            # Check if the detail column exists to provide richer options
            if project_id_col in df_alloc.columns:
                # Use both ID and description for a more detailed dropdown
                project_cols = [allocation_project_col, project_id_col]
                df_projects = df_alloc[project_cols].dropna(subset=[allocation_project_col]).drop_duplicates(subset=[allocation_project_col])
                project_list = df_projects.to_dict('records')
            else:
                # Fallback to just using the description if the ID column isn't found
                descriptions = sorted([str(name) for name in df_alloc[allocation_project_col].dropna().unique() if str(name).strip()])
                # Create a list of dictionaries for a consistent structure in the template
                project_list = [{allocation_project_col: desc} for desc in descriptions]

            # Sort the list alphabetically by project description
            project_list = sorted(project_list, key=lambda x: x[allocation_project_col])
            
            session['project_list'] = project_list
            # Store column names in session to be used by the template
            session['project_desc_col_name'] = allocation_project_col
            session['project_id_col_name'] = project_id_col if project_id_col in df_alloc.columns else None
        except Exception as e:
            flash(f"Error reading the allocation file to get project names: {e}", 'error')
            return redirect(url_for('start_processing'))

        return redirect(url_for('step2_primary_filter'))

    return render_template('step1_paths.html')

@app.route('/step2', methods=['GET', 'POST'])
def step2_primary_filter():
    """Step 2: Get the primary filter (company name)."""
    if 'main_filepath' not in session:
        flash('Please start from the beginning.', 'error')
        return redirect(url_for('home'))

    if request.method == 'POST':
        company_to_filter = request.form.get('company_name')
        project_description = request.form.get('project_description')

        if not company_to_filter:
            flash('Please select a company.', 'error')
            return redirect(url_for('step2_primary_filter'))
        if not project_description:
            flash('Please enter a project description.', 'error')
            return redirect(url_for('step2_primary_filter'))

        session['company_name'] = company_to_filter
        session['project_description'] = project_description
        return redirect(url_for('step3_advanced_filters'))

    # Pass company list to the template for the dropdown
    company_list = session.get('company_list', [])
    project_list = session.get('project_list', [])
    project_desc_col = session.get('project_desc_col_name', 'Project Description')
    project_id_col = session.get('project_id_col_name')
    return render_template('step2_company.html',
                           company_list=company_list,
                           project_list=project_list,
                           project_desc_col=project_desc_col,
                           project_id_col=project_id_col)

@app.route('/step3', methods=['GET', 'POST'])
def step3_advanced_filters():
    """Step 3: Get advanced options and process the files."""
    if 'company_name' not in session:
        flash('Please complete the previous step first.', 'error')
        return redirect(url_for('step2_primary_filter'))

    if request.method == 'POST':
        company_to_filter = session.get('company_name')
        # Create output path
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_company_name = "".join(c for c in company_to_filter if c.isalnum()).rstrip()
        output_filename = f"filtered_{safe_company_name}_{timestamp}.xlsx"
        output_filepath = os.path.join(app.config['DOWNLOAD_FOLDER'], output_filename)

        # Group all parameters into a dictionary for a cleaner function call
        filter_params = {
            'main_file_path': session.get('main_filepath'),
            'designation_file_path': session.get('designation_filepath'),
            'allocation_file_path': session.get('allocation_filepath'),
            'company_name': company_to_filter,
            'project_description': session.get('project_description'),
            'main_sheet': request.form.get('sheet_name') or 'Associate Summary',
            'main_company_col': request.form.get('column_name') or 'Parent AccountName',
            'main_designation_col': request.form.get('main_designation_col') or 'Designation',
            'designation_sheet': request.form.get('designation_sheet') or 'Sheet1',
            'allocation_sheet': request.form.get('allocation_sheet') or 'Base sheet',
            'allocation_project_col': request.form.get('allocation_project_col') or 'Project Description',
            'associate_id_col': request.form.get('associate_id_col') or 'Associate ID',
            'output_path': output_filepath
        }

        # Process the file
        status, data = process_excel_file(filter_params)

        # Clear the session after processing
        session.clear()

        if status == "error":
            flash(data, 'error')
            return redirect(url_for('start_processing'))

        return redirect(url_for('success', filename=output_filename, count=data, company=company_to_filter))

    return render_template('step3_advanced.html')

@app.route('/success')
def success():
    """Displays a success message and a link to the downloaded file."""
    filename = request.args.get('filename')
    count = request.args.get('count', 0)
    company = request.args.get('company', 'the specified company')
    return render_template('success.html', filename=filename, count=count, company=company)

@app.route('/downloads/<filename>')
def download_file(filename):
    """Serves files from the download directory."""
    return send_from_directory(app.config['DOWNLOAD_FOLDER'], filename, as_attachment=True)

@app.route('/favicon.ico')
def favicon():
    """Handles the browser's request for a favicon, preventing 404 errors in the log."""
    return '', 204

if __name__ == '__main__':
    # Use host='0.0.0.0' to make it accessible on your network
    app.run(debug=True, host='0.0.0.0', port=8080)